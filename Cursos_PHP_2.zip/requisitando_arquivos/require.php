<?php
// Require requisita um arquivo e se não encontrá-lo ou encontrar um erro, ele para a execução
	require("gravar.php");
	Gravar("Teste Require <br/>", "file.txt")
 ?>

 <?php 
// require_once não permite repetir a execução de uma chamada caso ela ja exista
 	require_once("ler.php");
	$texto = Leitura("file.txt");

	echo $texto; 
?>