<?php
// Include solicita o arquivo e mesmo que encontre um erro a exxecução não para 
	include("gravar.php");
	Gravar("Teste Include <br/>", "file.txt")
 ?>

 <?php 
// Include_onde não permite uma solicitação repetida
	include_once("ler.php");
	$texto = Leitura("file.txt");

	echo $texto; 
?>

