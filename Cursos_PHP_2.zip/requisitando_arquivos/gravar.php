<?php 

	function Gravar (string $texto, string $arquivo) {
		$fp = fopen($arquivo, "a+"); // "a+" faz alterações no documento
		fwrite($fp, "{$texto} <br>\r\n"); // "\r" faz ele voltar para o inicio do paragrafo e "\n" quebra uma linha 
		fclose($fp);
	}
	 
 ?>