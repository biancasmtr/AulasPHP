<?php 
	require_once("gravar.php");
	Gravar("Require", "file.txt");

	require_once("ler.php");
	$texto = Leitura("file.txt");

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Requisitando Arquivos</title>
</head>
<body>
	<div>
		<?php 
			echo Leitura("file.txt");
		?>
	</div>
</body>
</html>