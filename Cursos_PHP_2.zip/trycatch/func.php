<?php 
function AbrirConexao(){
	$connection = new PDO("mysql:host=localhost;dbname=curso_phps;charset=utf8",'root', '');
	return $connection;
}


 ?>