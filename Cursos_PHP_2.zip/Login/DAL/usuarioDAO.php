<?php 

require_once("Model/usuario.php");

class UsuarioDAO{	

	private $debug = true;
	private $dir = "Arquivos";

	public function Cadastrar(Usuario $usuario) {
		try {
			$fileName = $usuario->getEmail() . ".txt";
			if (!$this->VerificaArquivoExiste($fileName)) {
				// faz o cadastro
				$diretorioCompleto = $this->dir . "/" . $fileName;
				$fopen = fopen($diretorioCompleto, "w");

				$str = "{$usuario->getNome()};{$usuario->getEmail()};{$usuario->getSenha()};{$usuario->getData()}";
				if ($fwrite($fopen, $str)) {
					return 1; //usuario cadastrado com sucesso
					fclose($fopen);
				}else {
					fclose($fopen);
					return -10; // erro ao tentar cadastrar
				}
			} else {
				return -1; //usuario ja cadastrado
			}
		} catch (Exception $ex) {
			if ($this->debug) {
				echo $ex->getMessage();
			}
		}
	}
	private function VerificaArquivoExiste() {
		$diretorioCompleto = $this->$dir. "/" .$nomeArquivo;
		// file exists verifica se um arquivo existe
		if (file_exists($diretorioCompleto)) {
			return true;
		} else {
			return false;
		}
	}


}
 ?>
