<?php 
	


	function Gravar (string $arquivo, string $texto) {
		$arquivo = date("d/m/Y - H:i:s") . ".txt";
		$fp = fopen($arquivo, "a+"); // "a+" faz alterações no documento
		fwrite($fp, "{$texto} <br>\r\n"); // "\r" faz ele voltar para o inicio do paragrafo e "\n" quebra uma linha 
		fclose($fp);
	}
	date_default_timezone_set('America/Sao_Paulo');
 	Gravar(date("d/m/Y H:i:s"), "file.txt");
 ?>

 <?php 
 	function Leitura(string $arquivo){
 		$fp = fopen($arquivo, "r");
 		$texto = fread($fp, filesize($arquivo));
 		fclose($fp);
 		return $texto;
 	}

 	echo Leitura($arquivo . ".txt");

  ?>