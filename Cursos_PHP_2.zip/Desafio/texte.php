<?php 
function Gravar(string $arquivo, string $texto) {
	$dir = date("d/m/Y-H:i:s"); 
	$arquivo = "C:/xampp/htdocs/Cursos_PHP_2/Desafio/arquivos/".$dir.".txt";

	if (!$arquivo) {
		$fp = fopen($arquivo, "a+");
		fwrite($fp, "{$texto}\r\n");
		fclose($fp);
	}
	
}

Gravar("arquivo.txt", date("d/m/Y H:i:s")); 

 ?>