<?php 

    $arquivo = ("arquivos/arquivo.txt");

    $cep = filter_input(INPUT_POST, "txtCep", FILTER_SANITIZE_NUMBER_INT);
    $logradouro = filter_input(INPUT_POST, "txtLogradouro", FILTER_SANITIZE_STRING);
    $bairro = filter_input(INPUT_POST, "txtBairro", FILTER_SANITIZE_STRING);
    $cidade = filter_input(INPUT_POST, "txtCidade", FILTER_SANITIZE_STRING);
    $estado = filter_input(INPUT_POST, "txtEstado", FILTER_SANITIZE_STRING);

    if (isset($_POST["cep"])) {
        $cep = $_POST["cep"];
    }
    if (isset($_POST["logradouro"])) {
        $logradouro = $_POST["logradouro"];
    }
    if (isset($_POST["bairro"])) {
        $bairro = $_POST["bairro"];
    }
    if (isset($_POST["cidade"])) {
        $cidade = $_POST["cidade"];
    }
    if (isset($_POST["estado"])) {
        $estado = $_POST["estado"];
    }
    $str = "CEP: {$cep}|Logradouro: {$logradouro}|Bairro:{$bairro}|Cidade:{$cidade}|Estado:{$estado}";

function Gravar () {}
/*    function Gravar (string $str, string $arquivo) {
        $fp = fopen($arquivo, "a+");
        fwrite($fp, "{$str} <br>\r\n");
        fclose($fp);
}*/

  ?>